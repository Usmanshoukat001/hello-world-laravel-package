<?php

namespace HelloWorld;

class Hello
{

    public function userName($username)
    {
        return "hello this is $username";
    }
}
